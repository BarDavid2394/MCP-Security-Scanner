"""Recognize visible pathlib text flowing to a tool return, including helpers."""
import ast


def carries_file_text(node):
    if node is None: return False
    if isinstance(node, (ast.Compare, ast.Constant)): return False
    if isinstance(node, ast.IfExp):
        return carries_file_text(node.body) or carries_file_text(node.orelse)
    if isinstance(node, ast.Call):
        if getattr(node, "_resolved_name", "") in {"len", "bool", "isinstance", "hasattr", "int", "float"}:
            return False
        if isinstance(node.func, ast.Attribute) and node.func.attr in {"read_text", "read_bytes"}:
            receiver = node.func.value
            if isinstance(receiver, ast.Call) and getattr(receiver, "_resolved_name", "") in {
                    "pathlib.Path", "pathlib.PosixPath", "pathlib.WindowsPath"}:
                return True
    return any(carries_file_text(child) for child in ast.iter_child_nodes(node))
